#include <stdio.h>
#include <stdbool.h>
#include <string>
#include <dirent.h>
#include <time>

int first_choice() {
    int choice = -1;
    printf("1. Select file to process\n2. Exit Program\n Enter a choice 1 or 2:");

    if(scanf("%d", choice) != 1 ) {
        return -1;
    }
    return choice;
}

int second_choice() {
    int choice = -1;
    printf("Which file you want to process?\nEnter 1 to pick the largest file\nEnter 2 to pick the smallest file\nEnter 3 to specify the name of the file");
    if(scanf("%d", choice) != 1 ) {
        return -1;
    }
    return choice;
}

void process(FILE* file) {
    char dir_name[1000];
    struct stat stat_buf;
    do {
        sprintf(dir_name, "burrelni.movies.%d", rand() % 100000);
    } while(stat(dir_name, &stat_buf) != -1);
    printf("Creating directory %s\n", dir_name);
    mkdir(dir_name, 750);
    char f_name[100];
    for(int i = 1920; i < 2022; ++i) {
        sprintf(f_name, "%d.txt", i);
        int fd = open(f_name, O_CREAT|O_WRONLY, 640);
        close(fd);
    }
}

void process_size(bool(*comp)(FILE*, FILE*)) {
    struct dirent *dp;
    DIR *dfd;

    if((dfd = opendir("./")) == NUL) {
        fprintf(stderr, "Cannot open local directory\n");
        return -1;
    }

    char s_name[1000];
    char c_name[1000];

    FILE* s_ptr = NULL;
    FILE* c_ptr = NULL;

    while((dp = readdir(dfd)) != null) {
        struct stat stat_buf;
        sprintf(c_name, "%s/%s", dir, dp->d_name);
        if (stat(c_name, &stat_buf) == -1) {
            printf("failed to stat file %s\n", c_name);
            continue;
        }

        if ( (stat_buf.st_mode & S_IFMT) == S_IFDIR)
            continue;

        if(strncmp("movies_", c_name, 7) != 0 || strncmp(c_name + strlen(c_name) - 4, ".csv", 4)) {
            continue;
        }

        c_ptr = fopen(c_name, "r");
        if (c_ptr == NULL) {
            printf("failed to open file %s\n", c_name);
            continue;
        }
        if(s_ptr == NULL) {
            strcpy(s_name, c_name);
            s_ptr = c_ptr;
        } else {
            if(comp(c_ptr, s_ptr)) {
                fclose(s_ptr);
                strcpy(s_name,c_name);
                memset(c_name, 0, 1000);
                c_ptr = NULL;
            } else {
                memset(c_name, 0, 1000);
                c_ptr = NULL;
            }
        }
    }
    process(s_ptr);

}


bool fsmaller(FILE* l, FILE* r) {
    size_t l_size, r_size;
    fseek(l, 0, SEEK_END);
    l_size = ftell(l);
    fseek(l, 0, SEEK_SET);
    fseek(r, 0, SEEK_END);
    r_size = ftell(l);
    fseek(r, 0, SEEK_SET);
    return l_size < r_size;
}

bool flarger(FILE* l, FILE* r) {
    size_t l_size, r_size;
    fseek(l, 0, SEEK_END);
    l_size = ftell(l);
    fseek(l, 0, SEEK_SET);
    fseek(r, 0, SEEK_END);
    r_size = ftell(l);
    fseek(r, 0, SEEK_SET);
    return l_size > r_size;
}

bool process_specify() {
    char f_name[1000];
    while(true) {
        printf("Enter a file name: ");
        scanf(f_name, "%s");
        struct stat stat_buf;
        if( stat(f_name, &stat_buf) == -1) {
            return false;
        }  else {
            FILE* f_ptr = fopen(f_name, "r");
            process(f_ptr);
        }
    }
}

void process_file() {
    int choice = 0;
    while(choice > 3 || choice < 1) {
        choice = second_choice();
        switch(choice) {
            case 1:
                process_size(*fsmaller);
                return;
            case 2:
                process_size(*flarger);
                return;
            case 3:
                if(!process_specify()) {
                    continue;
                }
                return;
            default:
                printf("Please enter a valid choice.\n");
                break;
        }
    }

}

int main() {
    int choice = 0;
    while(choice != 2) {
        choice = first_choice();
        if(choice == 1) {
            process_file();
        } else if(choice != 2){
            printf("Invalid choice.\n");
            continue;
        }
    }
}
